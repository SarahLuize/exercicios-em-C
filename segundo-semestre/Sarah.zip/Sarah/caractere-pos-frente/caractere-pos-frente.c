#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max 50

int main()
{
   int i, j, len;
   char string1[max], string2[max];

   printf("Informe uma string: \n");
   gets(string1);
   len = strlen(string1);

   j=0;
   for(i=1; i<len; i++) {
      string2[j] += string1[i];
      j++;
   }
   string2[i] += '\0';
   printf("%s", string2);
}
