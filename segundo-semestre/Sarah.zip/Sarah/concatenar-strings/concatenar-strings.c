#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
   int i=0, j=0, len, len2;
   char string1[20], string2[20], string3[40];

   printf("Informe uma string: \n");
   gets(string1);

   printf("Informe outra string: \n");
   gets(string2);

   len = strlen(string1);
   len2 = strlen(string2);

   for(i=0; i<len; i++) {
      string3[i] = string1[i];
   }

   string3[len+1] = ' ';

   j=0;
   for(i=len+1; j<len2+1; i++) {
      string3[i] = string2[j];
      j++;
   }
      printf("String concatenada: %s", string3);
}
