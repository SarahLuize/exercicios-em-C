#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max 50

int main()
{
   int i, j, len;
   char string[max];

   printf("Informe uma string: \n");
   gets(string);

   len = strlen(string);
   j=0;
   for(i=len-1; i<string[j]!='\0'; i--) {
      if(string[j] != string[i]) {
         printf("Nao e palindromo");
         return 0;
      }
      else {
         printf("Palindromo.");
         return 0;
      }
      j++;
   }
}
